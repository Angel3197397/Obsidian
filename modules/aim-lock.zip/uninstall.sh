#!/system/bin/sh
B=/data/local/tmp/obsidian_naim

[ -s $B/bk_tsens.txt ]   && settings put system touch_sensitivity $(cat $B/bk_tsens.txt)
[ -s $B/bk_palm.txt ]    && settings put system touch_palm_rejection $(cat $B/bk_palm.txt)
[ -s $B/bk_long.txt ]    && settings put secure long_press_timeout $(cat $B/bk_long.txt)
[ -s $B/bk_multi.txt ]   && settings put secure multi_press_timeout $(cat $B/bk_multi.txt)
[ -s $B/bk_keyrep.txt ]  && settings put secure key_repeat_timeout $(cat $B/bk_keyrep.txt)
[ -s $B/bk_nav.txt ]     && settings put secure navigation_mode $(cat $B/bk_nav.txt)
[ -s $B/bk_wa.txt ]      && settings put global window_animation_scale $(cat $B/bk_wa.txt)
[ -s $B/bk_ta.txt ]      && settings put global transition_animation_scale $(cat $B/bk_ta.txt)
[ -s $B/bk_ada.txt ]     && settings put global animator_duration_scale $(cat $B/bk_ada.txt)
[ -s $B/bk_pointer.txt ] && settings put system pointer_speed $(cat $B/bk_pointer.txt)

settings delete system peak_refresh_rate 2>/dev/null
settings delete system min_refresh_rate 2>/dev/null
settings delete system touch_sampling_rate 2>/dev/null
settings delete system maximum_touch_sampling_rate 2>/dev/null
settings delete system adaptive_refresh_rate 2>/dev/null

rm -rf $B
echo "[Neural Aim X] Revertido."