#!/system/bin/sh
# Neural Aim X v2.0 - AGGRESSIVE MODE
B=/data/local/tmp/obsidian_naim
mkdir -p $B

# ============ BACKUPS COMPLETOS ============
settings get system touch_sensitivity                  > $B/bk_tsens.txt     2>/dev/null
settings get system touch_palm_rejection               > $B/bk_palm.txt      2>/dev/null
settings get system touch_sampling_rate                > $B/bk_samp.txt      2>/dev/null
settings get system maximum_touch_sampling_rate        > $B/bk_maxsamp.txt   2>/dev/null
settings get secure long_press_timeout                 > $B/bk_long.txt      2>/dev/null
settings get secure multi_press_timeout                > $B/bk_multi.txt     2>/dev/null
settings get secure key_repeat_timeout                 > $B/bk_keyrep.txt    2>/dev/null
settings get secure navigation_mode                    > $B/bk_nav.txt       2>/dev/null
settings get global window_animation_scale             > $B/bk_wa.txt        2>/dev/null
settings get global transition_animation_scale         > $B/bk_ta.txt        2>/dev/null
settings get global animator_duration_scale            > $B/bk_ada.txt       2>/dev/null
settings get system peak_refresh_rate                  > $B/bk_peak.txt      2>/dev/null
settings get system min_refresh_rate                   > $B/bk_min.txt       2>/dev/null
settings get system adaptive_refresh_rate              > $B/bk_adapt.txt     2>/dev/null
settings get system pointer_speed                      > $B/bk_pointer.txt   2>/dev/null
settings get global always_finish_activities           > $B/bk_af.txt        2>/dev/null

# ============ OPTIMIZACIONES AGRESIVAS BASE ============
# Touch hardware
settings put system touch_sensitivity 1 2>/dev/null
settings put system touch_palm_rejection 0 2>/dev/null
settings put secure disable_touch_palm_rejection 1 2>/dev/null
settings put system touch_sampling_rate 240 2>/dev/null
settings put system maximum_touch_sampling_rate 240 2>/dev/null

# Timeouts agresivos
settings put secure long_press_timeout 150 2>/dev/null
settings put secure multi_press_timeout 150 2>/dev/null
settings put secure key_repeat_timeout 20 2>/dev/null

# Navegacion sin delay
settings put secure navigation_mode 0 2>/dev/null
settings put secure stylus_handwriting_enabled 0 2>/dev/null

# Animaciones ultra rapidas
settings put global window_animation_scale 0.2 2>/dev/null
settings put global transition_animation_scale 0.2 2>/dev/null
settings put global animator_duration_scale 0.2 2>/dev/null

# Refresh forzado
settings put system peak_refresh_rate 120 2>/dev/null
settings put system min_refresh_rate 90 2>/dev/null
settings put system adaptive_refresh_rate 0 2>/dev/null

# Pointer acceleration
settings put system pointer_speed 7 2>/dev/null

echo "[Neural Aim X v2.0] Modo agresivo aplicado."
echo "[Neural Aim X v2.0] Backups guardados en $B"