#!/system/bin/sh
rm -rf /data/local/tmp/obsidian_ffsens
echo "[FF Sens Calc] Removido."