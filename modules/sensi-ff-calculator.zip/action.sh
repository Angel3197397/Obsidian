#!/system/bin/sh
# Solo prepara cache de specs (por si la WebUI quiere comparar luego)
mkdir -p /data/local/tmp/obsidian_ffsens
chmod 777 /data/local/tmp/obsidian_ffsens

{
  echo "date=$(date)"
  echo "model=$(getprop ro.product.model)"
  echo "brand=$(getprop ro.product.manufacturer)"
  echo "android=$(getprop ro.build.version.release)"
  echo "sdk=$(getprop ro.build.version.sdk)"
  echo "soc=$(getprop ro.board.platform)"
} > /data/local/tmp/obsidian_ffsens/last_device.txt

echo "[FF Sens Calc] Listo."